const express = require("express"); //estamos importando a biblioteca express de forma REQUERIDA
const mysql = require("mysql2/promise"); //estamos chamando nossa biblioteca mysql2 com promise
const bcrypt = require("bcrypt"); //estamos importando nossa biblioteca bcrypt
const cors = require("cors"); //aqui estamos importando o cors
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

const dbconfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
};

app.get("/", (req, res) => {
    res.send("API FUNCIONANDO!")
});

// Cadastros

app.post("/CadastrarAluno", async (req, res) => {
    let connection;

    try {
        const { nome_aluno, email_aluno, contato, cpf, rua, numero, bairro, cidade, estado, cep, escola, motorista } = req.body;

        //validação
      /*  if (!nome_aluno || !email_aluno || !contato || !cpf || !rua || !numero || !bairro || !cidade || !estado || !cep || !escola || !motorista) {
            return res.status(400).json({
                erro: "Nome, email e senha são obrigatórios."
            });
        }*/
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);
       
        const [resultado] =
            await connection.execute("INSERT INTO alunos (nome_aluno,email_aluno,contato,cpf,rua,numero,bairro,cidade,estado,cep,escola,motorista) VALUES(?,?,?,?,?,?,?,?,?,?,?,?);"
            [nome_aluno, email_aluno, contato, cpf, rua, numero, bairro, cidade, estado, cep, escola, motorista]
            );

            if(resultado.length == 0){
                return res.status(201).json({mensagem: "Erro na chamada."})
            };

        return res.status(201).json({
            mensagem: "Aluno cadastrado com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_aluno,
                email_aluno
            }
        });
    } catch (error) {
        console.error("Erro ao registrar aluno:", error);
        return res.status(500).json({
            mensagem: "Erro interno do servidor.",
            erro: error,

        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.post("/CadastrarEscola", async (req, res) => {
    let connection;

    try {
        const { nome_escola, rua, numero, bairro, cidade, estado, cep } = req.body;

        //validação
        if (!nome_escola || !rua || !numero || !bairro || !cidade || !estado || !cep) {
            return res.status(400).json({
                erro: "Nome da escola é obrigatório."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("INSERT INTO escolas (nome_escola,rua,numero,bairro,cidade,estado,cep) VALUES (?,?,?,?,?,?,?);"
            [nome_escola, rua, numero, bairro, cidade, estado, cep]
            );

        return res.status(201).json({
            mensagem: "Escola cadastrada com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_escola
            }
        });
    } catch (error) {
        console.error("Erro ao registrar escola:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.post("/CadastrarMotorista", async (req, res) => {
    let connection;

    try {
        const { nome_motorista, email_motorista, contato, cpf, cnh, rua, numero, bairro, cidade, estado, cep } = req.body;

        //validação
        if (!nome_motorista || !email_motorista || !contato || !cpf || !cnh || !rua || !numero || !bairro || !cidade || !estado || !cep) {
            return res.status(400).json({
                erro: "Nome, email e senha são obrigatórios."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("INSERT INTO motoristas (nome_motorista,email_motorista,contato,cpf,cnh,rua,numero,bairro,cidade,estado,cep) VALUES (?,?,?,?,?,?,?,?,?,?,?);"
            [nome_motorista, email_motorista, contato, cpf, cnh, rua, numero, bairro, cidade, estado, cep]
            );

        return res.status(201).json({
            mensagem: "Motorista cadastrado com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_motorista,
                email_motorista
            }
        });
    } catch (error) {
        console.error("Erro ao registrar motorista:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.post("/CadastrarResponsavel", async (req, res) => {
    let connection;

    try {
        const { nome_responsavel, email_responsavel, contato, cpf, rua, numero, bairro, cidade, estado, cep } = req.body;

        //validação
        if (!nome_responsavel || !email_responsavel || !contato || !cpf || !rua || !numero || !bairro || !cidade || !estado || !cep) {
            return res.status(400).json({
                erro: "Nome, email e senha são obrigatórios."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("INSERT INTO responsaveis (nome_responsavel,email_responsavel,contato,cpf,rua,numero,bairro,cidade,estado,cep) VALUES(?,?,?,?,?,?,?,?,?,?);"
            [nome_responsavel, email_responsavel, contato, cpf, rua, numero, bairro, cidade, estado, cep]
            );

        return res.status(201).json({
            mensagem: "Responsável cadastrado com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_responsavel,
                email_responsavel
            }
        });
    } catch (error) {
        console.error("Erro ao registrar Responsavel:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

// UPDATES

app.post("/UpdateAluno", async (req, res) => {
    let connection;

    try {
        const { nome_aluno, email_aluno, contato, cpf, rua, numero, bairro, cidade, estado, cep, escola, motorista } = req.body;

        //validação
        if (!nome_aluno || !email_aluno || !contato || !cpf || !rua || !numero || !bairro || !cidade || !estado || !cep || !escola || !motorista) {
            return res.status(400).json({
                erro: "Nome, email e senha são obrigatórios."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("UPDATE alunos SET nome_aluno = ?,email_aluno = ?,contato = ?,cpf = ?,rua = ?,numero = ?,bairro = ?,cidade = ?,estado = ?,cep = ?,escola = ?,motorista = ?;"
            [nome_aluno, email_aluno, contato, cpf, rua, numero, bairro, cidade, estado, cep, escola, motorista]
            );

        return res.status(201).json({
            mensagem: "Aluno atualizado com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_aluno,
                email_aluno
            }
        });
    } catch (error) {
        console.error("Erro ao atualizar aluno:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.post("/UpdateEscola", async (req, res) => {
    let connection;

    try {
        const { nome_escola, rua, numero, bairro, cidade, estado, cep } = req.body;

        //validação
        if (!nome_escola || !rua || !numero || !bairro || !cidade || !estado || !cep) {
            return res.status(400).json({
                erro: "Nome da escola é obrigatório."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("UPDATE escolas SET nome_escola = ?,rua = ?,numero = ?,bairro = ?,cidade = ?,estado = ?,cep = ?;"
            [nome_escola, rua, numero, bairro, cidade, estado, cep]
            );

        return res.status(201).json({
            mensagem: "Escola atualizada com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_escola
            }
        });
    } catch (error) {
        console.error("Erro ao atualizar escola:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.post("/UpdateMotorista", async (req, res) => {
    let connection;

    try {
        const { nome_motorista, email_motorista, contato, cpf, cnh, rua, numero, bairro, cidade, estado, cep } = req.body;

        //validação
        if (!nome_motorista || !email_motorista || !contato || !cpf || !cnh || !rua || !numero || !bairro || !cidade || !estado || !cep) {
            return res.status(400).json({
                erro: "Nome, email e senha são obrigatórios."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("UPDATE motoristas SET nome_motorista = ?,email_motorista = ?,contato = ?,cpf = ?,cnh = ?,rua = ?,numero = ?,bairro = ?,cidade = ?,estado = ?,cep = ?;"
            [nome_motorista, email_motorista, contato, cpf, cnh, rua, numero, bairro, cidade, estado, cep]
            );

        return res.status(201).json({
            mensagem: "Motorista atualizado com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_motorista,
                email_motorista
            }
        });
    } catch (error) {
        console.error("Erro ao atualizar motorista:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.post("/UpdateResponsavel", async (req, res) => {
    let connection;

    try {
        const { nome_responsavel, email_responsavel, contato, cpf, rua, numero, bairro, cidade, estado, cep } = req.body;

        //validação
        if (!nome_responsavel || !email_responsavel || !contato || !cpf || !rua || !numero || !bairro || !cidade || !estado || !cep) {
            return res.status(400).json({
                erro: "Nome, email e senha são obrigatórios."
            });
        }
        //conecta ao banco de dados pela biblioteca mysql e as configurações do dbconfig
        connection = await mysql.createConnection(dbconfig);

        const [resultado] =
            await connection.execute("UPDATE responsaveis SET nome_responsavel = ?,email_responsavel = ?,contato = ?,cpf = ?,rua = ?,numero = ?,bairro = ?,cidade = ?,estado = ?,cep = ?;"
            [nome_responsavel, email_responsavel, contato, cpf, rua, numero, bairro, cidade, estado, cep]
            );

        return res.status(201).json({
            mensagem: "Responsável atualizado com sucesso!",
            usuario: {
                id: resultado.insertId,
                nome_responsavel,
                email_responsavel
            }
        });
    } catch (error) {
        console.error("Erro ao atualizar Responsavel:", error);
        return res.status(500).json({
            erro: "Erro interno do servidor."
        });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

// Login geral

app.post("/login", async (req, res) => {
    let connection;

    try {
        const { email, senha, tipo } = req.body;

        //validação
        if (!email || !senha || !tipo) {
            return res.status(400).json({
                erro: "Email, senha e tipo são obrigatórios."
            });
        }
        // conexão com o banco de dados
        connection = await mysql.createConnection(dbconfig);

        // busca o usuario pelo email
        const [usuarios] = await connection.execute("select * from ? where email = ?", [tipo, email]);

        // se não encontrou usuario
        if (usuarios.length === 0) {
            return res.status(401).json({
                erro: "Email ou senha inválidos."
            });
        }
        const usuario = usuarios[0];

        // compara senha digitada com hash salvo
        const senhaCorreta = await bcrypt.compare(senha, usuario.senha);

        if (!senhaCorreta) {
            return res.status(401).json({
                erro: "Email ou senha inválidos"
            });
        }

        //sucesso
        return res.status(200).json({
            mensagem: "Login realizado com sucesso",
            usuario: {
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email
            }
        })

    } catch (err) {
        console.error("Erro ao fazer login.", error);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
})

app.listen(process.env.PORT, () => {
    console.log(`Servidor rodando em http://localhost:${process.env.PORT}`);
});