const API_URL = "http://localhost:3000";

// =======================
// ALUNO
// =======================
async function registrarAluno() {

    const nome = document.getElementById("nome_aluno").value;
    const email = document.getElementById("email_aluno").value;
    const contato = document.getElementById("contato_aluno").value;
    const cpf = document.getElementById("cpf_aluno").value;

    // endereço
    const rua = document.getElementById("rua_aluno").value;
    const numero = document.getElementById("numero_aluno").value;
    const bairro = document.getElementById("bairro_aluno").value;
    const cidade = document.getElementById("cidade_aluno").value;
    const estado = document.getElementById("estado_aluno").value;
    const cep = document.getElementById("cep_aluno").value;

    // relacionamentos
    const escola = document.getElementById("escola_aluno").value;
    const motorista = document.getElementById("motorista_aluno").value;
    
    try {
        const response = await fetch(`${API_URL}/CadastrarAluno`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                nome,
                email,
                contato,
                cpf,
                rua,
                numero,
                bairro,
                cidade,
                estado,
                cep,
                escola,
                motorista
            })
        });

        const data = await response.json();
        mostrarResposta(data);

    } catch (error) {
        mostrarResposta({ erro: "Erro ao conectar com a API" });
    }
}


// =======================
// RESPONSÁVEL
// =======================
async function registrarResponsavel() {

    const nome = document.getElementById("nome_responsavel").value;
    const email = document.getElementById("email_responsavel").value;
    const contato = document.getElementById("contato_responsavel").value;
    const cpf = document.getElementById("cpf_responsavel").value;

    const rua = document.getElementById("rua_responsavel").value;
    const numero = document.getElementById("numero_responsavel").value;
    const bairro = document.getElementById("bairro_responsavel").value;
    const cidade = document.getElementById("cidade_responsavel").value;
    const estado = document.getElementById("estado_responsavel").value;
    const cep = document.getElementById("cep_responsavel").value;

    try {
        const response = await fetch(`${API_URL}/responsaveis`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                nome,
                email,
                contato,
                cpf,
                rua,
                numero,
                bairro,
                cidade,
                estado,
                cep
            })
        });

        const data = await response.json();
        mostrarResposta(data);

    } catch (error) {
        mostrarResposta({ erro: "Erro ao conectar com a API" });
    }
}


// =======================
// MOTORISTA
// =======================
async function registrarMotorista() {

    const nome = document.getElementById("nome_motorista").value;
    const email = document.getElementById("email_motorista").value;
    const contato = document.getElementById("contato_motorista").value;
    const cpf = document.getElementById("cpf_motorista").value;
    const cnh = document.getElementById("cnh_motorista").value;

    const rua = document.getElementById("rua_motorista").value;
    const numero = document.getElementById("numero_motorista").value;
    const bairro = document.getElementById("bairro_motorista").value;
    const cidade = document.getElementById("cidade_motorista").value;
    const estado = document.getElementById("estado_motorista").value;
    const cep = document.getElementById("cep_motorista").value;

    try {
        const response = await fetch(`${API_URL}/motoristas`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                nome,
                email,
                contato,
                cpf,
                cnh,
                rua,
                numero,
                bairro,
                cidade,
                estado,
                cep
            })
        });

        const data = await response.json();
        mostrarResposta(data);

    } catch (error) {
        mostrarResposta({ erro: "Erro ao conectar com a API" });
    }
}


// =======================
// ESCOLA
// =======================
async function registrarEscola() {

    const nome = document.getElementById("nome_escola").value;

    const rua = document.getElementById("rua_escola").value;
    const numero = document.getElementById("numero_escola").value;
    const bairro = document.getElementById("bairro_escola").value;
    const cidade = document.getElementById("cidade_escola").value;
    const estado = document.getElementById("estado_escola").value;
    const cep = document.getElementById("cep_escola").value;

    try {
        const response = await fetch(`${API_URL}/escolas`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                nome,
                rua,
                numero,
                bairro,
                cidade,
                estado,
                cep
            })
        });

        const data = await response.json();
        mostrarResposta(data);

    } catch (error) {
        mostrarResposta({ erro: "Erro ao conectar com a API" });
    }
}

// =======================
// RESPOSTA
// =======================
function mostrarResposta(msg) {

    const resposta = document.getElementById("resposta");

    if (!resposta) {
        alert(JSON.stringify(msg, null, 2));
    } else {
        resposta.innerText =
            msg.mensagem || msg.erro || "Resposta desconhecida";
    }
}