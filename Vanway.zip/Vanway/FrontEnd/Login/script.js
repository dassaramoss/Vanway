const API_URL = "http://localhost:3000";

async function login() {
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;

    // faça validação para caso os campos não estiverem preenchidos

    //DEPOIS
    try {
        const response = await fetch(`${API_URL}/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ email, senha })
        });

        const data = await response.json();

        mostrarResposta(data);
    } catch (error) {
        mostrarResposta("Erro ao conectar com a API")
    }

    function mostrarResposta(msg) {
        const resposta = document.getElementById("resposta");

        if (!resposta) {
            alert(JSON.stringify(msg, null, 2)); // erro
        } else {
            resposta.innerText = msg.mensagem || msg.erro || "resposta desconhecida" // acerto
        }
    }
}